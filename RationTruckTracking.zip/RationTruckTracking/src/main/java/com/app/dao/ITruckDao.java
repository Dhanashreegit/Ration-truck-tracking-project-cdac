

  package com.app.dao; import com.app.pojos.*; import
  org.springframework.data.jpa.repository.JpaRepository;
  
  public interface ITruckDao extends JpaRepository<TruckDriverDetails, Integer>
  {
  
  }
 