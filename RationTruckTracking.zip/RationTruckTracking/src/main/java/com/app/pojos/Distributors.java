package com.app.pojos;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.ManyToAny;



@Entity
public class Distributors {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer distributorID ;
    private String distributorName ;
    private long distributorContactNumber ;
    private String distributorAddress ;
    
   @OneToMany(mappedBy = "distributor", cascade = CascadeType.ALL )
      private List<Customers> customerList = new ArrayList<>() ;
    
   // private List<Ration> RationList = new ArrayList<>();
    
    
	public Distributors() {
		super();
	}


	public Distributors(String distributorName, long distributorContactNumber, String distributorAddress) {
		super();
		this.distributorName = distributorName;
		this.distributorContactNumber = distributorContactNumber;
		this.distributorAddress = distributorAddress;
	}


	public Integer getDistributorID() {
		return distributorID;
	}


	public void setDistributorID(Integer distributorID) {
		this.distributorID = distributorID;
	}


	public String getDistributorName() {
		return distributorName;
	}


	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}


	public long getDistributorContactNumber() {
		return distributorContactNumber;
	}


	public void setDistributorContactNumber(long distributorContactNumber) {
		this.distributorContactNumber = distributorContactNumber;
	}


	public String getDistributorAddress() {
		return distributorAddress;
	}


	public void setDistributorAddress(String distributorAddress) {
		this.distributorAddress = distributorAddress;
	}


	public List<Customers> getCustomerList() {
		return customerList;
	}


	public void setCustomerList(List<Customers> customerList) {
		customerList = customerList;
	} 


/*	public List<Ration> getRationList() {
		return RationList;
	}


	public void setRationList(List<Ration> rationList) {
		RationList = rationList;
	} */
   
	public void addCustomers(Customers cust)
	{
		//p ---> c
		customerList.add(cust);
		//c ---> p
		cust.setDistributor(this);
	}
	public void removeCustomers(Customers cust)
	{
		customerList.remove(cust);
	  cust.setDistributor(null);
	}

	
	
}
