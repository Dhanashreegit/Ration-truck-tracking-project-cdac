
  package com.app.repository;
  
  import org.springframework.data.jpa.repository.JpaRepository;
  
  import com.app.pojos.TruckDriverDetails;
  
  public interface TruckRepository extends
  JpaRepository<TruckDriverDetails,Integer> {
  
  
  }
 