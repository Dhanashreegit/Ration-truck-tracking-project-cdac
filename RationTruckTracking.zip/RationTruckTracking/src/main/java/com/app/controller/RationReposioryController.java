package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Customers;

import com.app.pojos.Ration;
import com.app.repository.RationRepository;
import com.app.services.IRationService;

@Controller
@Validated
@RequestMapping("/ration")
public class RationReposioryController {
   @Autowired
	private IRationService serv;
   
   @PutMapping
	public String updateGoodsDetails(@PathVariable int rid, @RequestParam String name,
			                                               int cost,int qtn,Model m) {
	    Ration upRation=new Ration(name,cost,qtn);
		System.out.println("in update ration " + rid + " " + upRation);
		Ration goods=serv.updateGoods(rid, upRation);
		if(goods == null)
		{
			m.addAttribute("msg","Updation Failed");
			return "/ration/upform";
		}
		m.addAttribute("msg","Update Successfully");
		return "/ration/list";
	}
   @GetMapping("/regist")
   public String regForm()
   {
 	  return "/ration/reg";
   }
   @PostMapping
	public String addGoodsDetails(@RequestParam String name,
                                                                         int cost,int qtn,Model m) {
	   Ration newGoods=new Ration(name,cost,qtn);
	   System.out.println("in add Ration " + newGoods);
	   Ration rt = serv.insertRation(newGoods);
	   if(rt == null)
	   {
		   m.addAttribute("msg","Insertion Failed");
		   return "/ration/reg";
	   }
	   m.addAttribute("msg","Goods Added");
		return  "/ration/succ";
	}
   @GetMapping
	public String getAllGoodsDetails(Model m) {
		List<Ration> rationList =serv.getAllRation();
		m.addAttribute("msg",rationList);
		return "/ration/list";
	}
   
   @DeleteMapping("/delete/{rationId}")
	public String  deleteGoodsDetails(@PathVariable int rationId) {
		System.out.println("in delete customer " + rationId);
		
		serv.deleteById(rationId);
		return "/ration/list";


	}
}
