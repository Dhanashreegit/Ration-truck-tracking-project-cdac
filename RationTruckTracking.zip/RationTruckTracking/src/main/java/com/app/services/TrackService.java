
  package com.app.services;
  
  import java.util.List; import java.util.Optional;
  
  import org.springframework.beans.factory.annotation.Autowired; import
  org.springframework.stereotype.Service; import
  org.springframework.transaction.annotation.Transactional;
  
  import com.app.cust_excs.ResourceNotFoundException; import
  com.app.dao.ITrackDao; import com.app.pojos.Ration; import
  com.app.pojos.TrackingDetails;
  
  @Service
  
  @Transactional public class TrackService implements ITrackService{
  
  @Autowired private ITrackDao dao;
  
  @Override public List<TrackingDetails> getAllTrack() {
  System.out.println("service impl class "+getClass().getName()); return
  dao.findAll(); }
  
  @Override public TrackingDetails addTrack(TrackingDetails transientPOJO) {
   return dao.save(transientPOJO); }
  
  @Override public Optional<TrackingDetails> TrackById(int id) {
	  
 return dao.findById(id); }
  
  @Override public void deleteById(int id) { // TODO Auto-generated method stub
  dao.deleteById(id); }
  
  @Override public TrackingDetails updateTrack(int id, TrackingDetails t1) {
  Optional<TrackingDetails> t = dao.findById(id); if(t.isPresent()) {
  TrackingDetails track = t.get();
  track.setCurrentMessage(t1.getCurrentMessage());
  track.setDispatchedDateTime(t1.getDispatchedDateTime());
  track.setEstimatedArrivalDateTime(t1.getEstimatedArrivalDateTime());
  track.setStatus(t1.getStatus()); return track; }
  
  throw new ResourceNotFoundException("Invalid Tracks ID"); }
  
  @Override
  
  public TrackingDetails searchByCity(String city) { return
  dao.trackByCity(city); }
  
  }
 