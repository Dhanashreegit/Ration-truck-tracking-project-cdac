package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Distributors;

public interface DistributorRepository extends JpaRepository<Distributors,Integer> {

}
