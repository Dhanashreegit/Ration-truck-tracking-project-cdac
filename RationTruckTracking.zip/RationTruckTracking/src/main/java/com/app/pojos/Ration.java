package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ration {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer goodsId;
	private String goodsName ;
	private int goodsCost;
	private int goodsQuantity ;
	
	public Ration(String goodsName, int goodsCost, int goodsQuantity) {
		super();
		this.goodsName = goodsName;
		this.goodsCost = goodsCost;
		this.goodsQuantity = goodsQuantity;
	}

	public Ration() {
		super();
	}

	public Integer getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public int getGoodsCost() {
		return goodsCost;
	}

	public void setGoodsCost(int goodsCost) {
		this.goodsCost = goodsCost;
	}

	public int getGoodsQuantity() {
		return goodsQuantity;
	}

	public void setGoodsQuantity(int goodsQuantity) {
		this.goodsQuantity = goodsQuantity;
	}

	

}
