package com.app.controller;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



import com.app.pojos.Customers;
import com.app.pojos.Distributors;

import com.app.services.IDistributorService;

@Controller
@Validated
@RequestMapping("/distributor")
public class DistributorController {

	@Autowired
	private IDistributorService service;
	 
	 @GetMapping()
	  public String getForm()
	  {
		  return "/distributor/login";
	  }

		@GetMapping("/form")
		public String getDistributorByName(@RequestParam String disrtibutorName,Model m) {
			System.out.println("in get by name of distributor " + disrtibutorName);
			try {
				Distributors existDistributor = service.getDistributorByName(disrtibutorName);
				m.addAttribute("distributor",existDistributor);
				return "/distributor/display";
			} catch (RuntimeException e) {
				e.printStackTrace();
				return "/distributor/login";
			}
		}
		 @GetMapping("/regist")
		    public String regForm()
		    {
		  	  return "/distributor/reg";
		    }
	@PostMapping
	public String createNewDistributor(@RequestParam String name,long mob,
			                                                            String address,Model m) {
		Distributors newdistributor=new Distributors(name,mob,address);
		System.out.println("in create Customer " + newdistributor);
		
			Distributors newDistributor = service.createNewDistributor(newdistributor);
			if(newDistributor == null)
			{
				m.addAttribute("msg","Sorry,Try Again");
				return " ";
			}
			m.addAttribute("msg","Congratulation,You are Registered");
			return "/distributor/succ";
	}

	
	

	
	@GetMapping("/all")
	public String getAllDistributors(Model m)
	{
		List<Distributors> dlist = service.getAllDistributor();
		m.addAttribute("distributorList", dlist);
		return "/distributor/list";
	}
}
