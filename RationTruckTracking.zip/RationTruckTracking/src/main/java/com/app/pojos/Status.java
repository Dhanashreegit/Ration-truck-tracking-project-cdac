package com.app.pojos;

public enum Status {

	Arrived, OnTheWay, YetToBeDispatched;
	@Override
	public String toString()
	{
		return name().toLowerCase();
	}
}
