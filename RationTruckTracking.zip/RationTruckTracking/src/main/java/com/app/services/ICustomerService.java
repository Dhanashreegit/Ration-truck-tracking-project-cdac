package com.app.services;

import java.util.List;

import com.app.pojos.Admin;
import com.app.pojos.Customers;

public interface ICustomerService {

	public List<Customers> getAllCustomers() ;
	public Customers validateCustomer(String username, String password);
	public Customers registerCustomer(Customers transientPOJO);
	public void deleteById(int eid);
	public Customers updateCustomerDetails(int id, Customers c1) ;
}
