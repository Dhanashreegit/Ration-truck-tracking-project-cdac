package com.app.dao;

import java.util.List;

import com.app.pojos.Distributors;




public interface IDistributorDao {

	public Distributors createNewDistributor(Distributors newDistributor);
	public Distributors getDistributorByName(String name);
	public Distributors updateDistributor(Distributors updatedistributor);
	public Distributors getDisrtById(int id); 
	public Distributors deleteDistributor(Distributors deletableDistributor);
	public List<Distributors> getAllDistributor();
}
