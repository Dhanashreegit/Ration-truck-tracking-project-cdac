
  package com.app.controller;
  
  import java.time.LocalDate; import java.util.List; import java.util.Optional;
  
  import org.springframework.beans.factory.annotation.Autowired; import
  org.springframework.http.HttpStatus; import
  org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
  import org.springframework.web.bind.annotation.DeleteMapping; import
  org.springframework.web.bind.annotation.GetMapping; import
  org.springframework.web.bind.annotation.PathVariable; import
  org.springframework.web.bind.annotation.PostMapping; import
  org.springframework.web.bind.annotation.PutMapping; import
  org.springframework.web.bind.annotation.RequestBody; import
  org.springframework.web.bind.annotation.RequestMapping; import
  org.springframework.web.bind.annotation.RequestParam; import
  org.springframework.web.bind.annotation.RestController;
  
  import com.app.dto.ErrorResponse; import com.app.pojos.Customers; import
  com.app.pojos.Status; import com.app.pojos.TrackingDetails; import
  com.app.pojos.TruckDriverDetails; import
  com.app.repository.TrackingRepository;
import com.app.services.ITrackService;
  
  @Controller
  
  @RequestMapping("/track") 
  public class TrackingRepositoryController {
  
  @Autowired private ITrackService serv;
  @GetMapping("/")
  public String regForm()
  {
	  return "/track/add";
  }
  @PostMapping 
  public String addTrackingDetails(@RequestParam String
  dCity,String sCity,String dd,String ed, String trkno,String msg,String
  stat) {
  
  Status status = Status.valueOf(stat); 
  LocalDate date1=LocalDate.parse(dd);
  LocalDate date2=LocalDate.parse(ed);

  TrackingDetails trk = new
  TrackingDetails(sCity,dCity,date1,date2,status,msg,trkno);
  System.out.println("in add TrackingDetails" + trk);
  TrackingDetails
  track=serv.addTrack(trk);
  if(track == null)
  { return "/track/add"; }
  return
  "/track/succ"; }
  
  @GetMapping("/{trackId}")
  
  public String getTrackById(@PathVariable int trackId,Model m) {
  System.out.println("in get track" + trackId); Optional<TrackingDetails>
  trk=serv.TrackById(trackId); if(trk.isPresent()) { m.addAttribute("track",
  trk); return "/track/display"; } m.addAttribute("track", "invalid Id");
  return "/track"; }
  
  @PutMapping("/{custId}") public String updateTrackDetails(@PathVariable int
  trkId, @RequestParam String dCity,String sCity, LocalDate dd,LocalDate ed,
  String trkno,String msg,String stat,Model m) { Status status =
  Status.valueOf("stat"); TrackingDetails uptrk = new
  TrackingDetails(sCity,dCity,dd,ed,status,msg,trkno);
  System.out.println("in update customer " + trkId + " " + uptrk);
  TrackingDetails track= serv.updateTrack(trkId,uptrk);
  m.addAttribute("updated", track); return "/cust/display";
  
  
  }
  
  @DeleteMapping("/{trktId}") public String deleteTrackDetails(@PathVariable
  int trktId) { System.out.println("in delete track " + trktId);
  serv.deleteById(trktId); return "/track/last";
  
  
  }
  @GetMapping("/all")
  public String getAllTracks(Model m) {
  System.out.println("In track controller "+getClass().getName());
  List<TrackingDetails> tlist=serv.getAllTrack(); m.addAttribute("List",
  tlist); return "/track/list";
  }
  @GetMapping("/fcity")
  public String cityForm()
  {
	  return "/track/city";
  }
  @GetMapping("/city")
  
  public String getTrackByCity(@RequestParam String dcity,Model m) {
  System.out.println("in get track" + dcity); TrackingDetails track=
  serv.searchByCity(dcity); 
  if(track == null) { m.addAttribute("track",
  "invalid City"); return "/track/city"; } m.addAttribute("track", track);
  return "/track/page"; } }
  
  
 