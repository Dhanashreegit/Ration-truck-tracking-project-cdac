package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.app.dao.IAdminDao;
import com.app.pojos.*;

@Service
@Transactional
public class AdminService implements IAdminService {
 
	@Autowired
	private IAdminDao dao;
	
	@Override
	public List<Admin> getAllAdmin() {
		System.out.println("service impl class "+getClass().getName());
		return dao.findAll();
	}

	@Override
	public Admin validateAdmin(String username, String password) {
		// TODO Auto-generated method stub
		return dao.validateAdmin(username, password);
	}

	@Override
	public Admin registerAdminDetails(Admin transientPOJO) {
		// TODO Auto-generated method stub
		return dao.save(transientPOJO);
	}	
	
	@Override
	public Optional<Admin> findById(int eid) {
		// TODO Auto-generated method stub
		return dao.findById(eid);
	}

	@Override
	public void deleteById(int eid) {
		// TODO Auto-generated method stub
		dao.deleteById(eid);
	}

	

	
	
	
	
}

