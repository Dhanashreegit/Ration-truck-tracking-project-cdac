package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Customers {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
     private Integer customerId;
     private String customerName;
     private long customerContactNumber;
     private String customerAddress;
     @Column(unique = true)
     private String RationCardNumber;
     
     @ManyToOne
     @JoinColumn(name = "distributorID ",nullable = false)
     
     private  Distributors distributor;

  // private List<Ration> RationList=new ArrayList<>();
     
	

	public Customers() {
		super();
	}

	public Customers(String customerName, long customerContactNumber, String customerAddress, String rationCardNumber) {
		super();
		this.customerName = customerName;
		this.customerContactNumber = customerContactNumber;
		this.customerAddress = customerAddress;
		RationCardNumber = rationCardNumber;
	}

	public Customers( String customerName, long customerContactNumber, String customerAddress,
		String rationCardNumber,Distributors distributor) {
	super();

	this.customerName = customerName;
	this.customerContactNumber = customerContactNumber;
	this.customerAddress = customerAddress;
	this.RationCardNumber = rationCardNumber;
	//this.distributor=distributor;
}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getCustomerContactNumber() {
		return customerContactNumber;
	}

	public void setCustomerContactNumber(long customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getRationCardNumber() {
		return RationCardNumber;
	}

	public void setRationCardNumber(String rationCardNumber) {
		RationCardNumber = rationCardNumber;
	}

	public Distributors getDistributor() {
		return distributor;
	}

	public void setDistributor(Distributors distributor) {
		this.distributor = distributor;
	}

	@Override
	public String toString() {
		return "Customers [customerId=" + customerId + ", customerName=" + customerName + ", customerContactNumber="
				+ customerContactNumber + ", customerAddress=" + customerAddress + ", RationCardNumber="
				+ RationCardNumber + ", distributor=" + distributor + "]";
	}
     
    
     
     
     
	
     
     
}
