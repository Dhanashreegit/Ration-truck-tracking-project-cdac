package com.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IDistributorDao;
import com.app.pojos.Distributors;

@Service
@Transactional
public class DistributorService implements IDistributorService {

	@Autowired
	private IDistributorDao dao;
	public  Distributors createNewDistributor(Distributors newDistributor)
	  {
		  dao.createNewDistributor(newDistributor);
		  return newDistributor;
	  }
	
	@Override
	public Distributors getDistributorByName(String disName) {
		return 	dao.getDistributorByName(disName);
		
	}

	@Override
	public Distributors updateDistributorContactNumber(int id,Distributors updatedistributor) {
		
		Distributors existingDistributor = dao.getDisrtById(id);
		if (existingDistributor != null) {
			
			existingDistributor.setDistributorContactNumber(updatedistributor.getDistributorContactNumber());
			existingDistributor.setDistributorName(updatedistributor.getDistributorName());
			return dao.updateDistributor( existingDistributor);
		}
		return null;
	}
	public Distributors getDisrtById(int id) {
		return dao.getDisrtById(id);
	}

	@Override
	public Distributors deleteDistributor(int id) {
		
		Distributors existDistributor = dao.getDisrtById(id);
		
		if (existDistributor != null) {
			
			return dao.deleteDistributor(existDistributor);
		}
		return null;
	}
	@Override
	public List<Distributors> getAllDistributor(){
		
		return dao.getAllDistributor();
		
	}
	
}
