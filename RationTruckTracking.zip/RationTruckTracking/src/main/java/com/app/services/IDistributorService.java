package com.app.services;

import java.util.List;

import com.app.pojos.Distributors;

public interface IDistributorService {
  
	public  Distributors createNewDistributor(Distributors newDistributor);
	public Distributors getDistributorByName(String disName);
	public Distributors updateDistributorContactNumber(int id,Distributors updatedistributor);
	//public Distributors getDisrtById(int id) ;
	public Distributors deleteDistributor(int id);
	public List<Distributors> getAllDistributor();
}
