package com.app.services;

import java.util.List;
import java.util.Optional;

import com.app.pojos.Admin;

public interface IAdminService {

	public List<Admin> getAllAdmin();
	public Optional<Admin> findById(int eid);
	public void deleteById(int eid);
	public Admin registerAdminDetails(Admin transientPOJO);
	public Admin validateAdmin(String username, String password);
}
