package com.app.services;

import java.util.List;
import java.util.Optional;


import com.app.pojos.Ration;

public interface IRationService {
	
	public List<Ration> getAllRation();
	public Ration insertRation(Ration transientPOJO) ;
	public void deleteById(int eid);
	public Optional<Ration> findById(int id);
	public Ration updateGoods(int id, Ration r1);
}
