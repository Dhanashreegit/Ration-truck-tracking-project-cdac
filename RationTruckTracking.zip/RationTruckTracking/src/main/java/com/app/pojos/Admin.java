package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Admin {
 
	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer adminId;
	    @Column(name="empName")
		private String adminName;
	    @Column(name="empEmail")
		private String adminEmail;
		private String empID;
		
		
		public Admin(Integer adminId, String adminName, String adminEmail, String empID) {
			super();
			this.adminId = adminId;
			this.adminName = adminName;
			this.adminEmail = adminEmail;
			this.empID = empID;
		}

		

		public Admin(String adminName, String adminEmail, String empID) {
			super();
			this.adminName = adminName;
			this.adminEmail = adminEmail;
			this.empID = empID;
		}



		public Admin() {
			super();
		}


		public Integer getAdminId() {
			return adminId;
		}


		public void setAdminId(Integer adminId) {
			this.adminId = adminId;
		}


		public String getAdminName() {
			return adminName;
		}


		public void setAdminName(String adminName) {
			this.adminName = adminName;
		}


		public String getAdminEmail() {
			return adminEmail;
		}


		public void setAdminEmail(String adminEmail) {
			this.adminEmail = adminEmail;
		}


		public String getEmpID() {
			return empID;
		}


		public void setEmpID(String empID) {
			this.empID = empID;
		}


		@Override
		public String toString() {
			return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", adminEmail=" + adminEmail + ", empID="
					+ empID + "]";
		}
		
		
		

}
