
  package com.app.services;
  
  import java.util.List;
  
  import com.app.pojos.TruckDriverDetails;
  
  public interface ITruckService {
  
  public List<TruckDriverDetails> getAllTruckDetails(); public
  TruckDriverDetails registerTruck(TruckDriverDetails transientPOJO); public
  void deleteById(int eid); }
 