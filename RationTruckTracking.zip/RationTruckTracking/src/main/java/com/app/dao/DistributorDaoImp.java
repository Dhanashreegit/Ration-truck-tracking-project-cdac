package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Distributors;




@Repository
public class DistributorDaoImp implements IDistributorDao {
  
	@Autowired
	  private EntityManager mngr;
	
	@Override
	public Distributors createNewDistributor(Distributors newDistributor) {
		mngr.persist(newDistributor);
		return newDistributor;
	}
	@Override
	public Distributors getDistributorByName(String name) {
		String jpql = "select d from Distributors d where d.distributorName=:distname";
		return mngr.createQuery(jpql, Distributors.class).setParameter("distname", name).getSingleResult();
	}
	@Override
	public Distributors updateDistributor(Distributors updatedistributor) {
		
		
		return mngr.merge(updatedistributor);
	}
	@Override
	public Distributors getDisrtById(int fundId) {
		// TODO Auto-generated method stub
		return mngr.find(Distributors.class, fundId);
	}
	@Override
	public Distributors deleteDistributor(Distributors deletableDistributor)
	{
		mngr.remove(deletableDistributor);;
		return deletableDistributor ;
	}
	@Override
	public List<Distributors> getAllDistributor()
	{
		String query="select d from Distributors d";
		return mngr.createQuery(query, Distributors.class).getResultList();
		
	}
}	
	
	
	

