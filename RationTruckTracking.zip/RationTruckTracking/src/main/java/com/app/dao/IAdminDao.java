package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojos.Admin;

public interface IAdminDao extends JpaRepository<Admin, Integer>{

	@Query("select a from Admin a where a.adminEmail=:username and a.empID=:password")
	Admin validateAdmin(String username, String password);
}
