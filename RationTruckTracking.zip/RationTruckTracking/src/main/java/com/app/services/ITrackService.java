
  package com.app.services;
  
  import java.util.List; import java.util.Optional;
  
  import com.app.pojos.TrackingDetails;
  
  public interface ITrackService {
  
  public List<TrackingDetails> getAllTrack(); public TrackingDetails
  addTrack(TrackingDetails transientPOJO); public Optional<TrackingDetails>
  TrackById(int id); public void deleteById(int id); public TrackingDetails
  updateTrack(int id, TrackingDetails t1); public TrackingDetails
  searchByCity(String city); }
 