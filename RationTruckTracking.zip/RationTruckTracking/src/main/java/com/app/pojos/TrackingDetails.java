
  package com.app.pojos;
  
  import java.time.LocalDate; import java.time.LocalDateTime;
  
  
  import javax.persistence.Entity; import javax.persistence.EnumType; import
  javax.persistence.Enumerated; import javax.persistence.GeneratedValue; import
  javax.persistence.GenerationType; import javax.persistence.Id; import
  javax.persistence.Temporal; import javax.persistence.TemporalType;
  
  
  @Entity public class TrackingDetails {
  
  @Id
  
  @GeneratedValue(strategy = GenerationType.IDENTITY) private int trackingId;
  private String sourceCity; 
  private String destinationCity;
  
  private LocalDate dispatchedDateTime ;
  
  private LocalDate estimatedArrivalDateTime ;
  
  @Enumerated(EnumType.STRING) private Status status; private String
  currentMessage; private String TruckRegNo;
  
  
  public TrackingDetails(int trackingId, String sourceCity, String
  destinationCity, LocalDate dispatchedDateTime, LocalDate
  estimatedArrivalDateTime, Status status, String currentMessage,
  TruckDriverDetails truckInfo,String TruckRegNo) { super(); this.trackingId =
  trackingId; this.sourceCity = sourceCity; this.destinationCity =
  destinationCity; this.dispatchedDateTime = dispatchedDateTime;
  this.estimatedArrivalDateTime = estimatedArrivalDateTime; this.status =
  status; this.currentMessage = currentMessage; this.TruckRegNo=TruckRegNo;
   }
  
  
  
  public TrackingDetails(String sourceCity, String destinationCity, LocalDate
  dispatchedDateTime, LocalDate estimatedArrivalDateTime, Status status, String
  currentMessage, String truckRegNo) { super(); this.sourceCity = sourceCity;
  this.destinationCity = destinationCity; this.dispatchedDateTime =
  dispatchedDateTime; this.estimatedArrivalDateTime = estimatedArrivalDateTime;
  this.status = status; this.currentMessage = currentMessage; TruckRegNo =
  truckRegNo; }
  
  
  
  public TrackingDetails() { super(); }
  
  
  public int getTrackingId() { return trackingId; }
  
  
  public void setTrackingId(int trackingId) { this.trackingId = trackingId; }
  
  
  public String getTruckRegNo() { return TruckRegNo; }
  
  
  public void setTruckRegNo(String truckRegNo) { TruckRegNo = truckRegNo; }
  
  
  public String getSourceCity() { return sourceCity; }
  
  
  public void setSourceCity(String sourceCity) { this.sourceCity = sourceCity;
  }
  
  
  public String getDestinationCity() { return destinationCity; }
  
  
  public void setDestinationCity(String destinationCity) { this.destinationCity
  = destinationCity; }
  
  
  public LocalDate getDispatchedDateTime() { return dispatchedDateTime; }
  
  
  public void setDispatchedDateTime(LocalDate dispatchedDateTime) {
  this.dispatchedDateTime = dispatchedDateTime; }
  
  
  public LocalDate getEstimatedArrivalDateTime() { return
  estimatedArrivalDateTime; }
  
  
  public void setEstimatedArrivalDateTime(LocalDate estimatedArrivalDateTime) {
  this.estimatedArrivalDateTime = estimatedArrivalDateTime; }
  
  
  public Status getStatus() { return status; }
  
  
  public void setStatus(Status status) { this.status = status; }
  
  
  public String getCurrentMessage() { return currentMessage; }
  
  
  public void setCurrentMessage(String currentMessage) { this.currentMessage =
  currentMessage; }
  
  
  @Override public String toString() { return "TrackingDetails [trackingId=" +
  trackingId + ", sourceCity=" + sourceCity + ", destinationCity=" +
  destinationCity + ", dispatchedDateTime=" + dispatchedDateTime +
  ", estimatedArrivalDateTime=" + estimatedArrivalDateTime + ", status=" +
  status + ", currentMessage=" + currentMessage + "]"; }
  
 
  }
 