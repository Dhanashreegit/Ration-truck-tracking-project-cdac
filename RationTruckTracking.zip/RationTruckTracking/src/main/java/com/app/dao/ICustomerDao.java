package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojos.Admin;
import com.app.pojos.Customers;

public interface ICustomerDao extends JpaRepository<Customers,Integer> {

	@Query("select c from Customers c where c.customerName=:username and c.RationCardNumber=:password")
	Customers validateCust(String username, String password);
}
