package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Customers;

public interface CustomerRepository extends JpaRepository<Customers,Integer> {

}
