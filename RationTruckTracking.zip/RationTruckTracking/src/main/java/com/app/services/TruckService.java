package com.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ITruckDao;
import com.app.pojos.Admin;
import com.app.pojos.TruckDriverDetails;
@Service
@Transactional
public class TruckService implements ITruckService {

	@Autowired
	private ITruckDao dao;

@Override
public List<TruckDriverDetails> getAllTruckDetails() {
	System.out.println("service impl class "+getClass().getName());
	return dao.findAll();
	}
	
	@Override
	public TruckDriverDetails registerTruck(TruckDriverDetails transientPOJO) {
		// TODO Auto-generated method stub
		return dao.save(transientPOJO);
	}
	
	@Override
	public void deleteById(int eid) {
		// TODO Auto-generated method stub
		dao.deleteById(eid);
	}
}
