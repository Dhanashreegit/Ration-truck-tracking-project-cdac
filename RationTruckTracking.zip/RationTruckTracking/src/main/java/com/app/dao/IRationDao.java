package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Ration;

public interface IRationDao extends JpaRepository<Ration, Integer> {

	
}
