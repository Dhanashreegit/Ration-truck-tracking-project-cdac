package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	public HomeController() {
		System.out.println("in ctor of "+getClass().getName());
	}
	//@RequestMapping("/")
	@GetMapping("/")
	public String showWelcomePage() {
		System.out.println("in show welcome page");
		return "/index";//actual view name : /WEB-INF/views/index.jsp
	}

@GetMapping("/about")
public String aboutUs() {
	System.out.println("a");
	return "/home/aboutus";
}

@GetMapping("/help")
public String help() {
	System.out.println("h");
	return "/home/help";
	
}

@GetMapping("/contact")
public String ContactUs() {
	System.out.println("a");
	return "/home/contactus";
}
@GetMapping("/image")
public String Imagegal() {
	System.out.println("a");
	return "/home/Imagegal";
	
}
@GetMapping("/table")
public String contacttable() {
	System.out.println("a");
	return "/home/table";
}
@GetMapping("/map")
public String mapofmaha() {
	System.out.println("a");
	return "/home/map";
}
}