package com.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.cust_excs.ResourceNotFoundException;
import com.app.dao.ICustomerDao;
import com.app.pojos.*;

import java.util.Optional;

@Service
@Transactional
public class CustomerService implements ICustomerService {
	
	@Autowired
	private ICustomerDao dao;
	
	@Override
	public List<Customers> getAllCustomers() {
		System.out.println("service impl class "+getClass().getName());
		return dao.findAll();
	}
	
	@Override
	public Customers validateCustomer(String username, String password) {
		// TODO Auto-generated method stub
		return dao.validateCust(username, password);
	}

	@Override
	public Customers registerCustomer(Customers transientPOJO) {
		// TODO Auto-generated method stub
		return dao.save(transientPOJO);
	}
	@Override
	public void deleteById(int eid) {
		// TODO Auto-generated method stub
		dao.deleteById(eid);
	}
	@Override
	public Customers updateCustomerDetails(int id, Customers c1) {
		Optional<Customers>  e = dao.findById(id);
		if(e.isPresent())
		{
			Customers cust = e.get();
			cust.setCustomerContactNumber(c1.getCustomerContactNumber());
			return cust;
		}
		
		throw new ResourceNotFoundException("Invalid Customer ID");
	}
}
