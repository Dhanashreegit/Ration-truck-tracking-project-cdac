
  package com.app.pojos;
  
  import javax.persistence.Column; import javax.persistence.Entity; import
  javax.persistence.GeneratedValue; import javax.persistence.GenerationType;
  import javax.persistence.Id;
  
  @Entity public class TruckDriverDetails {
  
  @Id
  
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  
  @Column(name="TruckId") private Integer truckId;
  
  @Column(name="TruckDriverName") private String truckDriverName;
  
  @Column(name="TruckRegNum") private String truckRegnoNumber;
  
  @Column(name="DriverContactNumber") private long DriverContactNumber;
  
  
  public TruckDriverDetails(Integer truckId, String truckDriverName, String
  truckRegnoNumber, long driverContactNumber) { super(); this.truckId =
  truckId; this.truckDriverName = truckDriverName; this.truckRegnoNumber =
  truckRegnoNumber; this.DriverContactNumber = driverContactNumber; }
  
  
  
  public TruckDriverDetails(String truckDriverName, String truckRegnoNumber,
  long driverContactNumber) { super(); this.truckDriverName = truckDriverName;
  this.truckRegnoNumber = truckRegnoNumber; this.DriverContactNumber =
  driverContactNumber; }
  
  
  
  public TruckDriverDetails() { super(); }
  
  
  public Integer getTruckId() { return truckId; }
  
  
  public void setTruckId(Integer truckId) { this.truckId = truckId; }
  
  
  public String getTruckDriverName() { return truckDriverName; }
  
  
  public void setTruckDriverName(String truckDriverName) { this.truckDriverName
  = truckDriverName; }
  
  
  public String getTruckRegnoNumber() { return truckRegnoNumber; }
  
  
  public void setTruckRegnoNumber(String truckRegnoNumber) {
  this.truckRegnoNumber = truckRegnoNumber; }
  
  
  public long getDriverContactNumber() { return DriverContactNumber; }
  
  
  public void setDriverContactNumber(long driverContactNumber) {
  DriverContactNumber = driverContactNumber; }
  
  
  @Override public String toString() { return "TruckDriverDetails [truckId=" +
  truckId + ", truckDriverName=" + truckDriverName + ", truckRegnoNumber=" +
  truckRegnoNumber + ", DriverContactNumber=" + DriverContactNumber + "]"; }
  
  
  
  
  
  }
 