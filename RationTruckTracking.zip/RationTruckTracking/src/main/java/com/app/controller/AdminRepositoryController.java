package com.app.controller;



import java.awt.PageAttributes.MediaType;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;




import com.app.pojos.Admin;



import com.app.services.IAdminService;

@Controller
@RequestMapping("/adm")
public class AdminRepositoryController {

	@Autowired
	private IAdminService serv;
	
	public	AdminRepositoryController(){
		
	}
	
  @GetMapping
  public String getForm()
  {
	  return "/admin/login";
  }

	
    @GetMapping("/form")
	public  String getAdminByLogin(@RequestParam String uname,String pass,Model m)
    {
        System.out.println("in get admin " + uname);
        System.out.println("in get admin " + pass);
		
		Admin adm=serv.validateAdmin(uname, pass);
		
		if(adm==null)
		{
			System.out.println("in login null return ");
			return "/admin/login";
		    
			
		}else
		{
			System.out.println("in login credentials return ");
			m.addAttribute("admin",adm);
			return "/admin/display";//login form
		}
		
    	
    }

    @GetMapping("/regist")
    public String regForm()
    {
  	  return "/admin/reg";
    }
    
    @PostMapping
	public String registerAdmin(@RequestParam String name,String mail,String empid)
	{
    	Admin a = new Admin(name,mail,empid);
		System.out.println("in register new Employee "+a);
			 Admin ad=serv.registerAdminDetails(a);
			return "/admin/succ";
	}	
}
