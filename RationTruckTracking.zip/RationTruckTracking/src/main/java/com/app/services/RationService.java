package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.cust_excs.ResourceNotFoundException;

import com.app.dao.IRationDao;

import com.app.pojos.Ration;

@Service
@Transactional
public class RationService implements IRationService {

	@Autowired
	private IRationDao dao;
	
	@Override
	public List<Ration> getAllRation() {
		System.out.println("service impl class "+getClass().getName());
		return dao.findAll();
	}
	@Override
	public Ration insertRation(Ration transientPOJO) {
		// TODO Auto-generated method stub
		return dao.save(transientPOJO);
	}
	@Override
	public void deleteById(int eid) {
		// TODO Auto-generated method stub
		dao.deleteById(eid);
	}
	
	@Override
	public Optional<Ration> findById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}
	@Override
	public Ration updateGoods(int id, Ration r1) {
		Optional<Ration>  r = dao.findById(id);
		if(r.isPresent())
		{
			Ration goods = r.get();
			goods.setGoodsCost(r1.getGoodsCost());
			goods.setGoodsQuantity(r1.getGoodsQuantity());
			return goods;
		}
		
		throw new ResourceNotFoundException("Invalid Ration ID");
	}


}
